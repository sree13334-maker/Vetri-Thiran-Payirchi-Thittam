import html
import os
import requests
import streamlit as st

from backend.services.export_service import docx_bytes, pdf_bytes, txt_bytes
from backend.services.document_formatter import format_html_preview


st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide",
)

API_URL = os.getenv("LEGAL_EASE_API_URL", "http://127.0.0.1:8000").rstrip("/")
LOGO_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)),
    "assets",
    "logo.png",
)

st.markdown(
    """
    <style>
    .block-container {max-width: 1200px; padding-top: 2rem;}
    .legal-card {
        background: #111827;
        color: #f9fafb;
        padding: 24px;
        border-radius: 14px;
        max-height: 600px;
        overflow-y: auto;
        line-height: 1.7;
    }
    .small-note {color: #6b7280; font-size: 0.9rem;}
    </style>
    """,
    unsafe_allow_html=True,
)

if os.path.exists(LOGO_PATH):
    st.image(LOGO_PATH, width=120)

st.title("LegalEase")
st.caption("AI-Powered Legal Document Generator")
st.info(
    "LegalEase creates drafts from your inputs. Review the generated document "
    "carefully and obtain qualified legal advice where appropriate."
)

with st.form("legal_form"):
    col1, col2 = st.columns(2)

    with col1:
        document_type = st.text_input(
            "Document Type",
            placeholder="Freelance Work Contract",
        )
        parties = st.text_area(
            "Parties Involved",
            placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)",
            height=130,
        )

    with col2:
        effective_date = st.text_input(
            "Effective Date",
            placeholder="April 10, 2026",
        )
        terms = st.text_area(
            "Terms & Conditions",
            placeholder=(
                "Payment within 30 days; Confidentiality must be maintained; "
                "Either party may terminate with 15 days notice"
            ),
            height=130,
        )

    submitted = st.form_submit_button(
        "Generate Document",
        type="primary",
        use_container_width=True,
    )

if submitted:
    missing = []
    if not document_type.strip():
        missing.append("Document Type")
    if not parties.strip():
        missing.append("Parties Involved")
    if not terms.strip():
        missing.append("Terms & Conditions")
    if not effective_date.strip():
        missing.append("Effective Date")

    if missing:
        st.error("Please fill: " + ", ".join(missing))
    else:
        payload = {
            "document_type": document_type.strip(),
            "parties": parties.strip(),
            "terms": terms.strip(),
            "effective_date": effective_date.strip(),
        }

        with st.spinner("Generating your legal draft..."):
            try:
                response = requests.post(
                    f"{API_URL}/generate",
                    json=payload,
                    timeout=120,
                )
                response.raise_for_status()
                result = response.json()
                st.session_state["document"] = result["content"]
                st.session_state["doc_type"] = document_type.strip()
                st.session_state["terms"] = terms.strip()
                st.success("Document generated successfully.")
            except requests.RequestException as exc:
                st.error(
                    "Could not reach the FastAPI backend. "
                    f"Check that it is running at {API_URL}. Details: {exc}"
                )

if "document" in st.session_state:
    st.divider()
    st.subheader("Document Preview")

    preview_html = format_html_preview(st.session_state["document"])
    st.markdown(
        f'<div class="legal-card">{preview_html}</div>',
        unsafe_allow_html=True,
    )

    st.subheader("Edit Document")
    edited = st.text_area(
        "You can modify the generated draft here.",
        value=st.session_state["document"],
        height=500,
        key="edited_document",
    )
    st.session_state["document"] = edited

    txt_data = txt_bytes(edited)
    docx_data = docx_bytes(
        edited,
        st.session_state["doc_type"],
        st.session_state.get("terms", ""),
    )
    pdf_data = pdf_bytes(edited, st.session_state["doc_type"])

    c1, c2, c3 = st.columns(3)
    with c1:
        st.download_button(
            "Download TXT",
            data=txt_data,
            file_name="legalease_document.txt",
            mime="text/plain",
            use_container_width=True,
        )
    with c2:
        st.download_button(
            "Download DOCX",
            data=docx_data,
            file_name="legalease_document.docx",
            mime=(
                "application/vnd.openxmlformats-officedocument."
                "wordprocessingml.document"
            ),
            use_container_width=True,
        )
    with c3:
        st.download_button(
            "Download PDF",
            data=pdf_data,
            file_name="legalease_document.pdf",
            mime="application/pdf",
            use_container_width=True,
        )

    st.caption(
        "Tip: Put your own logo at assets/logo.png to add branding to DOCX/PDF."
    )

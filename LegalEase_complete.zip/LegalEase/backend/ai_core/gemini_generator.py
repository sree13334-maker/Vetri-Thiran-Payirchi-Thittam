import os
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()


class GeminiDocumentGenerator:
    """Generate structured legal-document drafts using Google's current GenAI SDK."""

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.model = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip()

        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY is missing. Add it to the .env file."
            )

        self.client = genai.Client(api_key=self.api_key)

    def _build_prompt(
        self,
        document_type: str,
        parties: str,
        terms: str,
        effective_date: str,
    ) -> str:
        term_list = [
            item.strip()
            for item in terms.replace("\n", ";").split(";")
            if item.strip()
        ]
        formatted_terms = "\n".join(f"- {item}" for item in term_list)

        return f"""
Create a professional legal-document DRAFT from the supplied information.

Document type:
{document_type}

Parties:
{parties}

Effective date:
{effective_date}

Requested terms:
{formatted_terms}

Requirements:
1. Use clear formal legal-document structure.
2. Include a title, introductory paragraph, numbered sections, and signature placeholders.
3. Do not invent names, addresses, money amounts, dates, laws, courts, or facts not supplied by the user.
4. If a necessary detail is missing, use a clear placeholder such as [INSERT ADDRESS].
5. Preserve every supplied term without changing its meaning.
6. Return plain text only. Do not use Markdown code fences.
7. This is a draft for review, not a substitute for advice from a qualified lawyer.
""".strip()

    def generate_document(
        self,
        document_type: str,
        parties: str,
        terms: str,
        effective_date: str,
    ) -> str:
        prompt = self._build_prompt(
            document_type=document_type,
            parties=parties,
            terms=terms,
            effective_date=effective_date,
        )

        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=5000,
            ),
        )

        text = (response.text or "").strip()
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text

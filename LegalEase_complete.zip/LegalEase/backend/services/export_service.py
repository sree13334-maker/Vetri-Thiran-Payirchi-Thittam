from backend.services.document_formatter import format_docx, format_pdf


def txt_bytes(text: str) -> bytes:
    return text.encode("utf-8")


def docx_bytes(text: str, doc_type: str, terms: str = "") -> bytes:
    return format_docx(text, doc_type, terms)


def pdf_bytes(text: str, doc_type: str) -> bytes:
    return format_pdf(text, doc_type)

# LegalEase - AI-Powered Legal Document Generator

LegalEase is a Streamlit + FastAPI application for generating editable legal-document
drafts with Google's Gemini API and exporting them to TXT, DOCX, and PDF.

The architecture follows the supplied project documentation:
- Streamlit frontend
- FastAPI backend
- Gemini AI integration
- Editable preview
- TXT/DOCX/PDF export
- Optional logo at `assets/logo.png`

## Project structure

```text
LegalEase/
├── backend/
│   ├── __init__.py
│   ├── main.py
│   ├── routes.py
│   ├── schemas.py
│   ├── ai_core/
│   │   ├── __init__.py
│   │   └── gemini_generator.py
│   └── services/
│       ├── __init__.py
│       ├── document_formatter.py
│       └── export_service.py
├── frontend/
│   └── app.py
├── assets/
│   └── README.txt
├── tests/
│   ├── __init__.py
│   ├── test_formatters.py
│   └── test_health.py
├── .env.example
├── .gitignore
├── Dockerfile
├── Procfile
├── requirements.txt
├── requirements-dev.txt
├── run_backend.bat
├── run_frontend.bat
└── README.md
```

## Windows / VS Code setup

Open this folder in VS Code.

### 1. Create a virtual environment

Open VS Code Terminal:

```powershell
python -m venv .venv
```

Activate it:

```powershell
.venv\Scripts\activate
```

If PowerShell blocks activation, use Command Prompt terminal and run:

```cmd
.venv\Scripts\activate.bat
```

### 2. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Configure Gemini

Copy `.env.example` and rename the copy to `.env`.

Then put your real key here:

```env
GEMINI_API_KEY=YOUR_REAL_KEY
GEMINI_MODEL=gemini-3.8-flash
LEGAL_EASE_API_URL=http://127.0.0.1:8000
```

Never upload `.env` or your API key to GitHub.

### 4. Optional logo

Put your logo here:

```text
assets/logo.png
```

If no logo is provided, the app still works.

## Run the application

You need two VS Code terminals.

### Terminal 1 - FastAPI

```powershell
.venv\Scripts\activate
python -m uvicorn backend.main:app --reload
```

Backend:
- http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/health

### Terminal 2 - Streamlit

```powershell
.venv\Scripts\activate
python -m streamlit run frontend/app.py
```

Streamlit will show a local URL, normally:

```text
http://localhost:8501
```

## Test

Run:

```powershell
pytest -q
```

For a manual end-to-end test:
1. Start FastAPI.
2. Start Streamlit.
3. Enter document type, parties, terms, and effective date.
4. Click Generate Document.
5. Edit the result.
6. Download TXT, DOCX, and PDF.
7. Open the downloaded files and verify formatting.

## Example input

Document Type:
```text
Freelance Work Contract
```

Parties:
```text
Jane Doe (Service Provider), TechNova Inc. (Client)
```

Terms:
```text
Payment within 30 days; Confidentiality must be maintained; Provider will deliver work by the agreed deadline; Either party may terminate with 15 days notice
```

Effective Date:
```text
April 10, 2026
```

## API example

POST `/generate`:

```json
{
  "document_type": "Freelance Work Contract",
  "parties": "Jane Doe (Service Provider), TechNova Inc. (Client)",
  "terms": "Payment within 30 days; Confidentiality must be maintained",
  "effective_date": "April 10, 2026"
}
```

## Important implementation note

The supplied documentation names Gemini 1.5 Pro and the older `google-generativeai` package.
This implementation uses Google's newer `google-genai` SDK and makes the model configurable
through `GEMINI_MODEL`. This avoids hard-coding a potentially unavailable legacy model.

## Legal note

Generated content is a draft. It should be reviewed for the relevant jurisdiction and facts
by a qualified legal professional when appropriate.

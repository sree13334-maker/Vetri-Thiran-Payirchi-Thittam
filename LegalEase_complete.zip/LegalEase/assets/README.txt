Optional logo:
1. Prepare a PNG image.
2. Rename it to logo.png.
3. Put it in this assets folder.

The application automatically uses assets/logo.png in generated DOCX/PDF files.

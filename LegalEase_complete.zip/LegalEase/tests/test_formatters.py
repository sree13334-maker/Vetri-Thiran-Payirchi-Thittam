from backend.services.document_formatter import sanitize_text, split_terms


def test_sanitize_text():
    assert sanitize_text("Hello \u201cLegalEase\u201d") == 'Hello "LegalEase"'


def test_split_terms():
    assert split_terms("One; Two\nThree") == ["One", "Two", "Three"]
